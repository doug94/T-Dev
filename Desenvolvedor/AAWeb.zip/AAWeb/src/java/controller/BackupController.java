package controller;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BackupController extends HttpServlet {    

    public BackupController() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action.equalsIgnoreCase("backup")) {
            String connectionURL = "jdbc:derby://localhost:1527/AABD";
            Connection conn = null;
            try {
                conn = DriverManager.getConnection(connectionURL, "root", "admin");
            } catch (SQLException ex) {
                Logger.getLogger(BackupController.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                backUpDatabase(conn);
            } catch (SQLException ex) {
                Logger.getLogger(BackupController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        } else if (action.equalsIgnoreCase("restaurar")){
            String connectionURL ="jdbc:derby://localhost:1527/AABD;user=root;password=admin;restoreFrom=/home/15111371/documents/"+request.getParameter("name");
            Connection conn = null;
            try {
                conn = DriverManager.getConnection(connectionURL, "root", "admin");
            } catch (SQLException ex) {
                Logger.getLogger(BackupController.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                conn.commit();
            } catch (SQLException ex) {
                Logger.getLogger(BackupController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        RequestDispatcher rd = request.getRequestDispatcher("/Backup.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    private void backUpDatabase(Connection conn) throws SQLException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss");
        System.out.println(sdf.format(System.currentTimeMillis()));
        
        String backupdirectory ="/home/15111371/Documents/"+sdf.format(System.currentTimeMillis());
        CallableStatement cs = conn.prepareCall("CALL SYSCS_UTIL.SYSCS_BACKUP_DATABASE(?)"); 
        cs.setString(1, backupdirectory);
        cs.execute(); 
        cs.close();
        System.out.println("backed up database to "+backupdirectory);
    }
    
    public static void restoreDatabase(Connection conn,String path)throws SQLException{

        //String backupPath = "C:\\mybacksup\\2015-05-02\\OOS_db";
        //"jdbc:derby://localhost:1527/aa"
       // String restoreUrl = "jdbc:derby://localhost:1527/aa;user=APP;password=APP;restoreFrom=" + path;
      
        //conn = DriverManager.getConnection(restoreUrl);
       //  conn.commit();
       // System.out.println("The database has been successfully restored");
        
        String databaseName = "jdbc:derby://localhost:1527/AABD;;user=root;password=admin;restoreFrom=" + path;
        String delete = "jdbc:derby://localhost:1527/AABD;shutdown=true";
        //try {
         //DriverManager.getConnection(delete);
       // } catch (SQLException e) {
         //   System.out.println(e);
         //Connection con;
         //try {
        //  conn = DriverManager.getConnection(databaseName);
        //  conn.commit();  
          try {                  
          // Class.forName("org.apache.derby.jdbc.ClientDriver");
          //} catch (Exception e1) {
          //     System.out.println(e1);
          //}

          conn = DriverManager.getConnection("jdbc:derby://localhost:1527/AABD;;user=root;password=admin;create=true");
          conn.commit();
          System.out.println("The database has been successfully restored");
         } catch (SQLException e1) {
              System.out.println(e1);
         }
        //}
     
    }
}