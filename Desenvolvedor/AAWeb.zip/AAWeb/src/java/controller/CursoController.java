package controller;

import dao.CursoDao;
import model.Curso;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CursoController extends HttpServlet {

    private static String insert = "/CadastroCurso.jsp";
    private static String edit = "/ModificarCurso.jsp";
    private static String lista = "/ListaCursos.jsp";
    private CursoDao dao;

    public CursoController() {
        super();
        dao = new CursoDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String redirect = "";
        String action = request.getParameter("action");
        String curriculo = request.getParameter("Curriculo");
        if (curriculo != null && action.equalsIgnoreCase("insert")) {
            Curso curso = new Curso();
            curso.setCurriculo(curriculo);
            curso.setNome(request.getParameter("Nome"));
            curso.setDescricao(request.getParameter("Descricao"));
            dao.addCurso(curso);
            redirect = lista;
            request.setAttribute("cursos", dao.getAll());
        } else if (action.equalsIgnoreCase("delete")) {
            String cursoCurriculo = request.getParameter("Curriculo");
            dao.removeCurso(cursoCurriculo);
            redirect = lista;
            request.setAttribute("cursos", dao.getAll());
        } else if (action.equalsIgnoreCase("editForm")) {
            request.setAttribute("curriculo", request.getParameter("Curriculo"));
            redirect = edit;
        } else if (action.equalsIgnoreCase("edit")) {
            String cursoCurriculo = request.getParameter("Curriculo");
            Curso curso = new Curso();
            curso.setCurriculo(curriculo);
            curso.setNome(request.getParameter("Nome"));
            curso.setDescricao(request.getParameter("Descricao"));
            dao.editCurso(curso);
            request.setAttribute("cursos", dao.getAll());
            redirect = lista;
        } else {
            redirect = insert;
        }
        RequestDispatcher rd = request.getRequestDispatcher(redirect);
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
