package controller;

import dao.VeteranoDao;
import model.Veterano;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VeteranoController extends HttpServlet {

    private static String insert = "/CadastroVeterano.jsp";
    private static String edit = "/ModificarVeterano.jsp";
    private static String lista = "/ListaVeteranos.jsp";
    private VeteranoDao dao;

    public VeteranoController() {
        super();
        dao = new VeteranoDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String redirect = "";
        String CPF = request.getParameter("CPF");
        String action = request.getParameter("action");
        if (CPF != null && action.equalsIgnoreCase("insert")) {
            Veterano veterano = new Veterano();
            System.out.println("CPF : " + CPF);
            System.out.println("Nome : " + request.getParameter("Nome"));
            System.out.println("Sobrenome : " + request.getParameter("Sobrenome"));
            veterano.setCPF(CPF);
            veterano.setNome(request.getParameter("Nome"));
            veterano.setSobrenome(request.getParameter("Sobrenome"));
            dao.addVeterano(veterano);
            redirect = lista;
            request.setAttribute("veteranos", dao.getAll());
            System.out.println("veterano criado");
        } else if (action.equalsIgnoreCase("delete")) {
            String veteranoCPF = request.getParameter("CPF");
            dao.removeVeterano(veteranoCPF);
            redirect = lista;
            request.setAttribute("veteranos", dao.getAll());
        } else if (action.equalsIgnoreCase("editForm")) {
            request.setAttribute("cpf", request.getParameter("CPF"));
            redirect = edit;
        } else if (action.equalsIgnoreCase("edit")) {
            String veteranoCPF = request.getParameter("CPF");
            Veterano veterano = new Veterano();
            veterano.setCPF(veteranoCPF);
            veterano.setNome(request.getParameter("Nome"));
            veterano.setSobrenome(request.getParameter("Sobrenome"));
            dao.editVeterano(veterano);
            request.setAttribute("veteranos", dao.getAll());
            redirect = lista;
        } else {
            redirect = insert;
        }
        RequestDispatcher rd = request.getRequestDispatcher(redirect);
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
