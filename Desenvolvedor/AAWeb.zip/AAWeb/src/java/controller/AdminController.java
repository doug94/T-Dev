package controller;

import dao.AdminDao;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdminController extends HttpServlet {

    private AdminDao dao;
    

    public AdminController() {
        super();
        dao = new AdminDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //String redirect = "";
        String adminUser = request.getParameter("adminUser");
        String adminPass = request.getParameter("adminPass");
        String adminPass2 = request.getParameter("adminPass2");
        String action = request.getParameter("action");
        
        if (action.equalsIgnoreCase("login") && adminUser != null && adminPass != null && adminPass.equals(adminPass2) && dao.verify(adminUser,adminPass)) {
            RequestDispatcher rd = request.getRequestDispatcher("/MainPage.jsp");
            rd.forward(request, response);
        } else if (action.equalsIgnoreCase("login")){
            RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
            rd.forward(request, response);
        }
        
        /* 
        if (uId != null && action.equalsIgnoreCase("insert")) {
            int ID = Integer.parseInt(uId);
            userBean utilisateur = new userBean();
            System.out.println("id : " + ID);
            System.out.println("nom : " + request.getParameter("nom"));
            System.out.println("prenom : " + request.getParameter("prenom"));
            utilisateur.setID(ID);
            utilisateur.setNom(request.getParameter("nom"));
            utilisateur.setPrenom(request.getParameter("prenom"));
            dao.addUser(utilisateur);
            redirect = liste;
            request.setAttribute("utilisateurs", dao.getAllUsers());
            System.out.println("le utilisateur est bien cr�e");
        } else if (action.equalsIgnoreCase("delete")) {
            String utilistaeurId = request.getParameter("ID");
            int uid = Integer.parseInt(utilistaeurId);
            dao.removeUser(uid);
            redirect = liste;
            request.setAttribute("utilisateurs", dao.getAllUsers());
            System.out.println("utilisateurs est bien supprimer");
        } else if (action.equalsIgnoreCase("editForm")) {
            request.setAttribute("id", request.getParameter("ID"));
            redirect = edit;
        } else if (action.equalsIgnoreCase("edit")) {
            String utilisateurId = request.getParameter("id");
            int uid = Integer.parseInt(utilisateurId);
            userBean utilisateur = new userBean();
            utilisateur.setID(uid);
            utilisateur.setNom(request.getParameter("nom"));
            utilisateur.setPrenom(request.getParameter("prenom"));
            dao.editUser(utilisateur);
            request.setAttribute("utilisateur", utilisateur);
            redirect = liste;
            System.out.println("utilisateur est bien modifier");
        } else if (action.equalsIgnoreCase("ListUser")) {
            request.setAttribute("utilisateurs", dao.getAllUsers());
        } else {
            redirect = INSERT;
        }
        RequestDispatcher rd = request.getRequestDispatcher(redirect);
        rd.forward(request, response);*/
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
