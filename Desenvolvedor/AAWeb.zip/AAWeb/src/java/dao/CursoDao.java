package dao;

import model.Curso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import dao.dbconnection.Conexao;

public class CursoDao {

    private Connection conn;

    public CursoDao() {
        conn = Conexao.getConnection();
    }

    public void addCurso(Curso curso) {
        try {
            String sql = "INSERT INTO curso (curriculo,nome,descricao) " + "VALUES(?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, curso.getCurriculo());
            ps.setString(2, curso.getNome());
            ps.setString(3, curso.getDescricao());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeCurso(String curriculo) {
        try {
            String sql = "DELETE FROM curso WHERE curriculo=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, curriculo);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void editCurso(Curso curso) {
        try {
            String sql = "UPDATE curso set nome=? , descricao=? where curriculo=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, curso.getNome());
            ps.setString(2, curso.getDescricao());
            ps.setString(3, curso.getCurriculo());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List getAll() {
        List lista = new ArrayList();
        try {
            String sql = "SELECT * FROM curso";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Curso curso = new Curso();
                curso.setCurriculo(rs.getString("curriculo"));
                curso.setNome(rs.getString("nome"));
                curso.setDescricao(rs.getString("descricao"));
                lista.add(curso);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public String getRoteiro(String curriculo){
        String roteiro = "";
        try {
            String sql = "SELECT roteiro FROM curso WHERE curriculo=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, curriculo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                roteiro = rs.getString("roteiro");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return roteiro;
    }
    
    public void setRoteiro(Curso curso) {
        try {
            String sql = "UPDATE curso set roteiro=? where curriculo=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, curso.getRoteiro());
            ps.setString(1, curso.getCurriculo());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public Curso getByCurriculo(String curriculo) {
        Curso veterano = new Curso();
        try {
            String sql = "SELECT * FROM curso WHERE curriculo=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, curriculo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                veterano.setCurriculo(rs.getString("curriculo"));
                veterano.setNome(rs.getString("nome"));
                veterano.setDescricao(rs.getString("descricao"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return veterano;
    }
}
