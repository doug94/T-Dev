package dao;

import model.Veterano;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import dao.dbconnection.Conexao;

public class VeteranoDao {

    private Connection conn;

    public VeteranoDao() {
        conn = Conexao.getConnection();
    }

    public void addVeterano(Veterano veterano) {
        try {
            String sql = "INSERT INTO \"veterano\" (\"CPF\",\"nome\",\"sobrenome\") " + "VALUES(?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, veterano.getCPF());
            ps.setString(2, veterano.getNome());
            ps.setString(3, veterano.getSobrenome());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeVeterano(String cpf) {
        try {
            String sql = "DELETE FROM \"veterano\" WHERE \"CPF\"=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, cpf);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void editVeterano(Veterano veterano) {
        try {
            String sql = "UPDATE \"veterano\" set \"nome\"=? , \"sobrenome\"=? where \"CPF\"=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, veterano.getNome());
            ps.setString(2, veterano.getSobrenome());
            ps.setString(3, veterano.getCPF());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List getAll() {
        List lista = new ArrayList();
        try {
            String sql = "SELECT * FROM \"veterano\"";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Veterano veterano = new Veterano();
                veterano.setCPF(rs.getString("CPF"));
                veterano.setNome(rs.getString("nome"));
                veterano.setSobrenome(rs.getString("sobrenome"));
                lista.add(veterano);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public Veterano getByCPF(String cpf) {
        Veterano veterano = new Veterano();
        try {
            String sql = "SELECT * FROM \"veterano\" WHERE \"CPF\"=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, cpf);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                veterano.setCPF(rs.getString("CPF"));
                veterano.setNome(rs.getString("nome"));
                veterano.setSobrenome(rs.getString("sobrenome"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return veterano;
    }
}
