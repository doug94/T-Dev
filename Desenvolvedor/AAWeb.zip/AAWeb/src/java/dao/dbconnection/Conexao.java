package dao.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
	private static Connection con = null;
	public static Connection getConnection(){
		if(con != null){
			return con;
		}
		else {
			try {
			   Class.forName("org.apache.derby.jdbc.ClientDriver");  
		            String url = "jdbc:derby://localhost:1527/AABD";
		            String user = "root";
		            String passwd = "admin";

                    con = DriverManager.getConnection(url,user,passwd);
		            System.out.println("Conexão feita !");
				
			} catch (ClassNotFoundException cne) {
				System.out.println("***Driver***");
				cne.printStackTrace();
			} catch (SQLException e) {
				System.out.println("***SQLException***");
				System.out.println(e);
			}
			return con;
		}
	}
}
