package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dao.dbconnection.Conexao;
import java.sql.ResultSet;
import model.Admin;

;

public class AdminDao {

    private Connection conn;

    public AdminDao() {
        conn = Conexao.getConnection();
    }

    public void changePass(Admin admin) {
        try {
            String sql = "UPDATE \"admin\" set \"adminPass\"=? where \"adminUser\"=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, admin.getPass());
            ps.setString(2, admin.getUser());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean verify(String adminUser, String adminPass) {
        try {
            String sql = "SELECT \"adminPass\" FROM \"admin\" where \"adminUser\"=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, adminUser);        
            ResultSet rs = ps.executeQuery();
            rs.next();
            return (rs.getString("adminPass").equals(adminPass));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
