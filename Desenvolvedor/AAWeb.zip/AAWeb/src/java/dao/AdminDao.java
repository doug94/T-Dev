package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dao.dbconnection.Conexao;
import java.sql.ResultSet;
import model.Admin;

;

public class AdminDao {

    private Connection conn;

    public AdminDao() {
        conn = Conexao.getConnection();
    }

    public void changePass(String user,String pass) {
        try {
            String sql = "UPDATE administrator set adminPass=? where adminUser=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, pass);
            ps.setString(2, user);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean verify(String adminUser, String adminPass) {
        try {
            String sql = "SELECT adminPass FROM administrator where adminUser=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, adminUser);        
            ResultSet rs = ps.executeQuery();
            rs.next();
            return (rs.getString("adminPass").equals(adminPass));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
