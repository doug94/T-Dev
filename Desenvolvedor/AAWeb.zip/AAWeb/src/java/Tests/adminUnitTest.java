package Tests;


import dao.AdminDao;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author marlon
 */
public class adminUnitTest {
    private AdminDao dao;
    
    public void main(){
        String pass1 = "abcd";
        String pass2 = "admin";
        dao.changePass("admin",pass1);
        System.out.println("Test1: "+dao.verify("admin", pass1));
        
        dao.changePass("admin",pass2);
        System.out.println("Test2: "+dao.verify("admin", pass2));
    }
    
}
