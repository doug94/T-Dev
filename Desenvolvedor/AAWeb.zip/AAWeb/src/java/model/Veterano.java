package model;

public class Veterano {
	private String CPF;
	private String nome;
	private String sobrenome;
	
	public String getCPF() {
		return CPF;
	}
	public String getNome() {
		return nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setCPF(String cpf) {
		this.CPF = cpf;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	
}