CREATE TABLE veterano (
  CPF varchar(11) NOT NULL,
  nome varchar(20) NOT NULL,
  sobrenome varchar(20) NOT NULL,
  PRIMARY KEY (CPF)
) ;

CREATE TABLE curso (
  curriculo varchar(10) NOT NULL,
  nome varchar(20) NOT NULL,
  descricao varchar(50) DEFAULT NULL,
  roteiro varchar(250) DEFAULT NULL,
  PRIMARY KEY (curriculo)
) ;

CREATE TABLE administrator (
  adminUser varchar(20) NOT NULL,
  adminPass varchar(20) NOT NULL,
  PRIMARY KEY (adminUser)
) ;

INSERT INTO administrator (adminUser,adminPass) VALUES ('admin','admin');